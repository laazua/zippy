### zippy

- 说明
1. 打包Python项目及其依赖为单个 .pyz 结尾的压缩文件
2. 可以通过Python解释器直接调用该压缩文件运行, 即: python example.pyz
3. 注意打包使用的的Python解释器和运行的Python解释器版本要一致

- 示例
```
# 项目结构
example/
├── app
│   ├── __init__.py
│   └── user.py
├── main.py
└── requirements.txt

# 打包
zippy example/ -o example.pyz -m main
```